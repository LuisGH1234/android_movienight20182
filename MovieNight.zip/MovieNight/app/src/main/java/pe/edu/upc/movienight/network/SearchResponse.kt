package pe.edu.upc.movienight.network

import pe.edu.upc.movienight.models.Search

class SearchResponse {
    val Search: ArrayList<Search>? = null
}