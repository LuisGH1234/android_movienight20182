package pe.edu.upc.movienight.network

class TitleResponse {
    val a: String? = ""
}